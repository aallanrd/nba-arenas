import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArenaEditComponent } from './arena-edit.component';

describe('TeamEditComponent', () => {
  let component: ArenaEditComponent;
  let fixture: ComponentFixture<ArenaEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArenaEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArenaEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
