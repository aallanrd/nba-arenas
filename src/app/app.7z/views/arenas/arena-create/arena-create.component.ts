import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../../../api.service';
import { FormControl, FormGroupDirective, FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';

@Component({
  selector: 'app-arena-create',
  templateUrl: './arena-create.component.html',
  styleUrls: ['./arena-create.component.css']
})
export class ArenaCreateComponent implements OnInit {
	
	matcher: any;
	arenaForm: FormGroup;
	name:string='';
	opened:string='';
	cost:string='';
	address:string='';
	capacity:string='';
	
	constructor(private router: Router, private api: ApiService, private formBuilder: FormBuilder) { }

	ngOnInit() {
		this.arenaForm = this.formBuilder.group({
		'name' : [null, Validators.required],
		'opened' : [null, Validators.required],
		'cost' : [null, Validators.required],
		'location' : [null, Validators.required],
		'address' : [null, Validators.required],
		'capacity' : [null, Validators.required]
		});
	}
	
	onFormSubmit(form:NgForm) {
		this.api.postArena(form)
		.subscribe(res => {
			let id = res['_id'];
			console.log(id);
			this.router.navigate(['/arena-details', id]);
		  }, (err) => {
			console.log(err);
		  });
	}

}
