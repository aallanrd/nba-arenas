import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArenaCreateComponent } from './arena-create.component';

describe('ArenaCreateComponent', () => {
  let component: ArenaCreateComponent;
  let fixture: ComponentFixture<ArenaCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ArenaCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArenaCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
