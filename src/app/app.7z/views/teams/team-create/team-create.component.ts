import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../../../api.service';
import { FormControl, FormGroupDirective, FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';

@Component({
  selector: 'app-team-create',
  templateUrl: './team-create.component.html',
  styleUrls: ['./team-create.component.css']
})
export class TeamCreateComponent implements OnInit {
	
	matcher: any;
	teamForm: FormGroup;
	name:string='';
	founded:string='';
	coach:string='';
	ownership:string='';
	affiliations:string='';
  
	constructor(private router: Router, private api: ApiService, private formBuilder: FormBuilder) { }

	ngOnInit() {
		this.teamForm = this.formBuilder.group({
		'name' : [null, Validators.required],
		'founded' : [null, Validators.required],
		'coach' : [null, Validators.required],
		'ownership' : [null, Validators.required],
		'affiliations' : [null, Validators.required]
		});
	}
	
	onFormSubmit(form:NgForm) {
		this.api.postTeam(form)
		.subscribe(res => {
			let id = res['_id'];
			console.log(id);
			this.router.navigate(['/team-details', id]);
		  }, (err) => {
			console.log(err);
		  });
	}

}
