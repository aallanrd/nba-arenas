import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';

import { AppComponent } from './app.component';
import { ViewsModule } from './views/views.module';
import { AppRoutes } from './app.routes.service';

import { LayoutModule } from '@angular/cdk/layout';


@NgModule({
  declarations: [
	AppComponent,
  ],
  imports: [  
	  BrowserModule,
	  HttpClientModule, 
	  ViewsModule,
	  AppRoutes
  ],
  providers: [{provide: LocationStrategy, useClass: HashLocationStrategy}],
  bootstrap: [AppComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AppModule { }
